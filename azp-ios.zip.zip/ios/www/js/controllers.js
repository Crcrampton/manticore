angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $ionicPopup, $timeout, $state, $http, $rootScope) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});
  
  //$scope.user = { IMG : "https://iwm-public.s3.amazonaws.com/pictures/picture-940-1443501790.jpg", NAME : "Colin Crampton", EMAIL : "crcrampton@gmail.com" };
  
  var creds = $.param({ userid : window.localStorage.getItem("uid"), token : window.localStorage.getItem("token") });
  $http.get('https://iwanamaker.com/api/json/user_details?'+creds).then(function(response) {
        $scope.user = response.data.USER;
  }, function(response) {
          // Response error
  });
  
  $scope.logout = function() {
    window.localStorage.removeItem("uid");
    window.localStorage.removeItem("token");
    $state.go('login');
  }
  
  $rootScope.showEventHome = false;
  
})

.controller('LoginCtrl', function($scope, $http, $ionicPopup, $state, $ionicLoading){ 
    $scope.data = {};
    
    $scope.login = function() {
      
      $ionicLoading.show({
            template: '<ion-spinner icon="lines"></ion-spinner>',
            noBackdrop: true,
duration: 10000
      });
      
      var creds = $.param({ email : $scope.data.username, pass : $scope.data.password });
      $http.get('https://iwanamaker.com/api/json/login?' + creds).then(function(response) {
          $ionicLoading.hide();
          if (response.data.ATTEMPT.SUCCESS == 1) {
            window.localStorage.setItem('uid', response.data.ATTEMPT.USERID);
            window.localStorage.setItem('token', response.data.ATTEMPT.TOKEN);
            $state.go('app.events');
          } else {
            $ionicLoading.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Login Failed',
                template: 'Please check your credentials.'
            });
          }
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    }
    
    $scope.register = function() {
      $state.go('register');
    }
})

.controller('RegisterCtrl', function($scope, $http, $ionicPopup, $state, $ionicLoading){ 
    $scope.data = {};
    
    $scope.initRegister = function() {
      
      $ionicLoading.show({
            template: '<ion-spinner icon="lines"></ion-spinner>',
            noBackdrop: true,
duration: 10000
      });
      
      if (typeof $scope.data.fullName === 'undefined') {
        var alertPopup = $ionicPopup.alert({
				  title: 'Name Field Empty',
				  template: 'Please enter your full name!'
        });
        $ionicLoading.hide();
        return false;
      }
      
      var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      if (!re.test($scope.data.username)) {
        var alertPopup = $ionicPopup.alert({
				  title: 'Invalid Email',
				  template: 'Please enter a valid email!'
        });
        $ionicLoading.hide();
        return false;
      }
      
      if (typeof $scope.data.password === 'undefined' || $scope.data.password.length < 4 ) {
        var alertPopup = $ionicPopup.alert({
				  title: 'Invalid Password',
				  template: 'Please enter a password that is at least 5 characters long.'
        });
        $ionicLoading.hide();
        return false;
      }
      
      if ($scope.data.password !== $scope.data.passwordMatch) {
        var alertPopup = $ionicPopup.alert({
				  title: 'Invalid Password',
				  template: 'Your passwords don\'t match!  Please type and retype your password.'
        });
        $ionicLoading.hide();
        return false;
      }
      
      var creds = $.param({ name : $scope.data.fullName, email : $scope.data.username, pass : $scope.data.password });
      $http.get('https://iwanamaker.com/api/json/register?' + creds).then(function(response) {
          $ionicLoading.hide();
          if (response.data.ATTEMPT.SUCCESS == 1) {
            window.localStorage.setItem('uid', response.data.ATTEMPT.USERID);
            window.localStorage.setItem('token', response.data.ATTEMPT.TOKEN);
            $state.go('app.events');
          } else {
            $ionicLoading.hide();
            var alertPopup = $ionicPopup.alert({
                title: 'Registraton Failed',
                template: 'There is already an account associated with this email.  Please go back to the login screen, or choose a different email.'
            });
          }
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    }
    
    $scope.backToLogin = function() {
      $state.go('login');
    }
})
 
.controller('EventsCtrl', function($scope, $http, $ionicPopup, $ionicLoading, $rootScope){ 
    $scope.data = {filter : "live"};
    
    $ionicLoading.show({
        template: '<ion-spinner icon="lines"></ion-spinner>',
        noBackdrop: true,
duration: 10000
    });
    
    $scope.$on('$ionicView.enter', function(e) {
	  $rootScope.showEventHome = false;
      $http.get('https://iwanamaker.com/api/json/events?leagueID=3155170').then(function(response) {
          $scope.events = (response.data.EVENT.length > 0) ? response.data.EVENT : response.data;
          $ionicLoading.hide();
      }, function(response) {
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
})

.controller('EventCtrl', function($scope, $http, $ionicPopup, $stateParams, $rootScope, $ionicHistory){ 
    $scope.data = {};
    $scope.eventID = $stateParams.eventID;
	
	$rootScope.showEventHome = true;
	$rootScope.eventHomeID = $stateParams.eventID;
    
    var params = $.param({ eventid : $stateParams.eventID, userid : window.localStorage.getItem("uid"), token : window.localStorage.getItem("token") });
    
    $scope.$on('$ionicView.enter', function(e) {
	  $ionicHistory.clearCache();
      $http.get('https://iwanamaker.com/api/json/event_details?'+params).then(function(response) {
          $scope.event = response.data.EVENT;
      }, function(response) {
            var alertPopup = $ionicPopup.alert({
                title: 'Service Unavailable',
                template: 'Please make sure you have an active internet connection and try again.'
            });
      });
    });
})

.controller('EventInfoCtrl', function($scope, $http, $ionicPopup, $stateParams, $ionicLoading){ 
    $scope.data = {};
    
    var params = $.param({ eventid : $stateParams.eventID });
    
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    $scope.$on('$ionicView.enter', function(e) {
      $http.get('https://iwanamaker.com/api/json/event_info?'+params).then(function(response) {
          $scope.event = response.data.EVENT;
		  $ionicLoading.hide();
      }, function(response) {
            $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
})

.controller('EventRoundsCtrl', function($scope, $http, $ionicPopup, $stateParams, $ionicLoading){ 
    $scope.data = {};
    
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    var params = $.param({ eventid : $stateParams.eventID });
    
    $scope.$on('$ionicView.enter', function(e) {
      $http.get('https://iwanamaker.com/api/json/event_rounds?'+params).then(function(response) {
          $scope.rounds = (response.data.EVENTROUND.length > 0) ? response.data.EVENTROUND : response.data;
          $ionicLoading.hide();
      }, function(response) {
            $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
})

.controller('EventGolfersCtrl', function($scope, $http, $ionicPopup, $stateParams, $ionicLoading){ 
    $scope.data = {};
    
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    var params = $.param({ eventid : $stateParams.eventID });
    
    $scope.$on('$ionicView.enter', function(e) {
      $http.get('https://iwanamaker.com/api/json/event_golfers?'+params).then(function(response) {
          $scope.golfers = (response.data.EVENTGOLFER.length > 0) ? response.data.EVENTGOLFER : response.data;
          $ionicLoading.hide();
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
})

.controller('EventGolferRoundsCtrl', function($scope, $http, $ionicPopup, $stateParams, $ionicLoading){ 
    $scope.data = {};
    
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    var params = $.param({ eventgolferid : $stateParams.event_golferID });
    
    $scope.$on('$ionicView.enter', function(e) {
      $http.get('https://iwanamaker.com/api/json/event_golfer_rounds?'+params).then(function(response) {
          $scope.rounds = (response.data.ROUND.length > 1) ? response.data.ROUND : [response.data.ROUND];
          $ionicLoading.hide();
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
})

.controller('PairingsCtrl', function($scope, $http, $ionicPopup, $stateParams, $ionicLoading){ 
    $scope.data = {};
    
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    var params = $.param({ eventroundid : $stateParams.event_roundID });
    
    $scope.$on('$ionicView.enter', function(e) {
      $http.get('https://iwanamaker.com/api/json/event_round_pairings?'+params).then(function(response) {
		  if (response.data.PAIRING != null) {
			$scope.pairings = (response.data.PAIRING.length > 0) ? response.data.PAIRING : response.data;
		  }
		  $ionicLoading.hide();
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
})

.controller('PlayCtrl', function ($scope, $stateParams, $state) {
	$scope.eventid = $stateParams.eventID;
})

.controller('LeaderboardCtrl', function($scope, $state, $http, $ionicPopup, $stateParams, $sce, $ionicLoading, $location){ 
    $scope.data = {};
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    $scope.$watch(function () { return $("table.leaderboard-table").find("tr:first td").length; }, function() {
      if ($("table.leaderboard-table").find("tr:first td").length > 5) {
        $("table.leaderboard-table").addClass("small")
      } else {
        $("table.leaderboard-table").removeAttr('style');
      }
    });
    
    var params = $.param({ eventid : $stateParams.eventID });
    
    $scope.$on('$ionicView.enter', function(e) {
      $http.get('https://iwanamaker.com/api/json/event_leaderboards?'+params).then(function(response) {
          $scope.leaderboards = (response.data.LEADERBOARD.length > 0) ? response.data.LEADERBOARD : response.data;
          $scope.activeLeaderboard = 0;
          $scope.refreshLeaderboard();
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
    
    $scope.prevLeaderboard = function() {
      if ($scope.activeLeaderboard == 0) {
        $scope.activeLeaderboard = $scope.leaderboards.length-1;
      } else {
        $scope.activeLeaderboard = $scope.activeLeaderboard-1;
      }
      
      $scope.refreshLeaderboard();
    }
    
    $scope.nextLeaderboard = function() {
      if ($scope.activeLeaderboard == $scope.leaderboards.length-1) {
        $scope.activeLeaderboard = 0;
      } else {
        $scope.activeLeaderboard = parseInt($scope.activeLeaderboard)+1;
      }
      
      $scope.refreshLeaderboard();
    }
    
    $scope.refreshLeaderboard = function() {
      
      $scope.$broadcast('scroll.refreshComplete');
      
      $ionicLoading.show({
        template: '<ion-spinner icon="lines"></ion-spinner>',
        noBackdrop: true,
duration: 10000
      });
      
      var requestLeaderboard = ($scope.leaderboards.length) ? $scope.leaderboards[$scope.activeLeaderboard] : $scope.leaderboards.LEADERBOARD;
      $scope.requestLeaderboard = requestLeaderboard;
      
      var params = $.param({ eventID : $stateParams.eventID,
                              leaderboardID : requestLeaderboard.TID,
                              flightID : requestLeaderboard.FLIGHTID,
                              leaderboard_type : requestLeaderboard.TYPE,
                              roundID : 0,
                              contestID : 0,
                              teamID : 0 });
      
      $http.get('https://iwanamaker.com/api/json/event_leaderboard_html?'+params).then(function(response) {
        $scope.leaderboardRows = response.data.leaderboard_html;
        $scope.leaderboardGoto = response.data.lbgoto;
        $scope.IDs = response.data.ids;
        $ionicLoading.hide();
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
      
      return true;
    }
    
    $scope.lbZoom = function (index) {
      if (index) {
        if ($scope.leaderboardGoto == 'team') {
          $state.go('app.events.event.play.team_leaderboard', { eventID : $stateParams.eventID, teamID : $scope.IDs[index-1], requestLeaderboard : $scope.requestLeaderboard });
        } else if ($scope.leaderboardGoto == 'scorecard') {
          $location.path('/app/events/'+$stateParams.eventID+'/play/scorecard/'+$scope.IDs[index-1]);
        } else {
	    // Do nothing
	}
      }
    }
})

.controller('TeamLeaderboardCtrl', function ($scope, $state, $http, $ionicPopup, $stateParams, $sce, $ionicLoading, $location) {
    $scope.refreshLeaderboard = function() {
      $ionicLoading.show({
        template: '<ion-spinner icon="lines"></ion-spinner>',
        noBackdrop: true,
duration: 10000
      });
      
      var requestLeaderboard = $stateParams.requestLeaderboard;
      
      var params = $.param({ eventID : $stateParams.eventID,
                              leaderboardID : requestLeaderboard.TID,
                              flightID : requestLeaderboard.FLIGHTID,
                              leaderboard_type : requestLeaderboard.TYPE,
                              roundID : 0,
                              contestID : 0,
                              teamID : $stateParams.teamID });
      
      $http.get('https://iwanamaker.com/api/json/event_leaderboard_html?'+params).then(function(response) {
        $scope.leaderboardRows = response.data.leaderboard_html;
        $scope.leaderboardGoto = response.data.lbgoto;
        $scope.IDs = response.data.ids;
        $ionicLoading.hide();
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    }
    
    $scope.lbZoom = function (index) {
      if (index) {
        if ($scope.leaderboardGoto == 'team') {
          $state.go('app.events.event.play.team_leaderboard', { eventID : $stateParams.eventID, teamID : $scope.IDs[index-1], requestLeaderboard : $scope.requestLeaderboard });
        } else {
          $location.path('/app/events/'+$stateParams.eventID+'/play/scorecard/'+$scope.IDs[index-1]);
        }
      }
    }
    
    $scope.refreshLeaderboard();
})

.controller('ScorecardCtrl', function($scope, $state, $http, $ionicPopup, $stateParams, $sce, $ionicLoading, $location){ 
    $scope.data = {};
    $scope.golferName = '';
    
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    var params = $.param({ eventgolferid : $stateParams.event_golferID });
    
    $scope.$on('$ionicView.enter', function(e) {
      $http.get('https://iwanamaker.com/api/json/event_golfer_rounds?'+params).then(function(response) {
          $scope.rounds = (response.data.ROUND.length > 1) ? response.data.ROUND : [response.data.ROUND];
          $scope.activeRound = 0;
          $scope.golferName = response.data.NAME;
          $scope.refreshRound();
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
    
    $scope.prevRound = function() {
      if ($scope.activeRound == 0) {
        $scope.activeRound = $scope.rounds.length-1;
      } else {
        $scope.activeRound = $scope.activeRound-1;
      }
      
      $scope.refreshRound();
    }
    
    $scope.nextRound = function() {
      if ($scope.activeRound == $scope.rounds.length-1) {
        $scope.activeRound = 0;
      } else {
        $scope.activeRound = parseInt($scope.activeRound)+1;
      }
      
      $scope.refreshRound();
    }
    
    $scope.refreshRound = function() {
      $ionicLoading.show({
        template: '<ion-spinner icon="lines"></ion-spinner>',
        noBackdrop: true,
duration: 10000
      });
      
      var requestRound = $scope.rounds[$scope.activeRound];
      
      var params = $.param({ roundid : requestRound.ROUNDID });
      
      $http.get('https://iwanamaker.com/api/json/round_scorecard?'+params).then(function(response) {
        $scope.scorecardRows = response.data.HOLES.HOLE;
        $ionicLoading.hide();
      }, function(response) {
          $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    }
})

.controller('ScoreCtrl', function($scope, $http, $ionicPopup, $stateParams, $ionicLoading, $ionicActionSheet, $location){ 
    $scope.data = {};
    $scope.fairways = new Array();
    
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    var params = $.param({ pairingid : $stateParams.pairingID });
    
    $scope.$on('$ionicView.loaded', function(e) {
      $http.get('https://iwanamaker.com/api/json/pairing_score_data?'+params).then(function(response) {
          $scope.currentHole = parseInt(response.data.CURRENTHOLE);
          $scope.roundNumber = response.data.ROUNDNUMBER;
          $scope.holeData = response.data.HOLES.HOLE;
          $scope.golfers = response.data.GOLFERS.GOLFER;
          $scope.format = response.data.FORMAT;
          $scope.stats = response.data.STATS == 1;
          
          if (response.data.SIDE == "full") {
            var holeButtons = [{text:'1'},{text:'2'},{text:'3'},{text:'4'},{text:'5'},{text:'6'},{text:'7'},{text:'8'},{text:'9'},
                           {text:'10'},{text:'11'},{text:'12'},{text:'13'},{text:'14'},{text:'15'},{text:'16'},{text:'17'},{text:'18'}];
            var holeButtonClicked = function(index) {
              $scope.currentHole = index+1;
              $scope.golfers = response.data.GOLFERS.GOLFER;
              return true;
            }
            $scope.nextHole = function() {
              $ionicLoading.show({
                template: '<ion-spinner icon="lines"></ion-spinner>',
                noBackdrop: true,
duration: 10000,
                duration: 200
              });
              var newHole = $scope.currentHole+1;
              if (newHole > 18) {
                newHole = 1;
              }
              $scope.currentHole = newHole;
            }
            $scope.prevHole = function() {
              $ionicLoading.show({
                template: '<ion-spinner icon="lines"></ion-spinner>',
                noBackdrop: true,
duration: 10000,
                duration: 200
              });
              var newHole = $scope.currentHole-1;
              if (newHole < 1) {
                newHole = 18;
              }
              $scope.currentHole = newHole;
            }
          } else if (response.data.SIDE == "front") {
            var holeButtons = [{text:'1'},{text:'2'},{text:'3'},{text:'4'},{text:'5'},{text:'6'},{text:'7'},{text:'8'},{text:'9'}];
            var holeButtonClicked = function(index) {
              $scope.currentHole = index+1;
              $scope.golfers = response.data.GOLFERS.GOLFER;
              return true;
            }
            $scope.nextHole = function() {
              var newHole = $scope.currentHole+1;
              if (newHole > 9) {
                newHole = 1;
              }
              $scope.currentHole = newHole;
            }
            $scope.prevHole = function() {
              var newHole = $scope.currentHole-1;
              if (newHole < 1) {
                newHole = 9;
              }
              $scope.currentHole = newHole;
            }
          } else if (response.data.SIDE == "back") {
            var holeButtons = [{text:'10'},{text:'11'},{text:'12'},{text:'13'},{text:'14'},{text:'15'},{text:'16'},{text:'17'},{text:'18'}];
            var holeButtonClicked = function(index) {
              $scope.currentHole = index+10;
              $scope.golfers = response.data.GOLFERS.GOLFER;
              return true;
            }
            $scope.nextHole = function() {
              var newHole = $scope.currentHole+1;
              if (newHole > 18) {
                newHole = 10;
              }
              $scope.currentHole = newHole;
            }
            $scope.prevHole = function() {
              var newHole = $scope.currentHole-1;
              if (newHole < 10) {
                newHole = 18;
              }
              $scope.currentHole = newHole;
            }
          }
          
          $scope.showHoleSelect = function() {

            // Show the HOLE SELECT action sheet
            $ionicActionSheet.show({
                 buttons: holeButtons,
                 titleText: '<i class="ion-flag"></i> Select a Hole',
                 cancelText: 'Back',
                 cancel: function() {
                      // add cancel code..
                    },
                 buttonClicked: holeButtonClicked,
               });            
             };
          
          $scope.showScoreSelect = function(scores, roundID) {
            // Show the SCORE SELECT action sheet
            $ionicActionSheet.show({
                 buttons: [{text:''},{text:'1'},{text:'2'},{text:'3'},{text:'4'},{text:'5'},{text:'6'},{text:'7'},{text:'8'},{text:'9'},
                           {text:'10'},{text:'11'},{text:'12'},{text:'13'},{text:'14'},{text:'15'},{text:'16'},{text:'17'},{text:'18'},
                           {text:'19'},{text:'20'},{text:'21'},{text:'22'},{text:'23'}],
                 titleText: '<i class="ion-log-in"></i> Enter Gross Score',
                 cancelText: 'Back',
                 cancel: function() {
                      // add cancel code..
                    },
                 buttonClicked: function(index) {
                  scores[$scope.currentHole-1] = -1;
                  
                  var params = $.param({ roundid : roundID, hole : $scope.currentHole, score : index });
                  $http.get('https://iwanamaker.com/api/json/update_round_score?'+params).then(function(response) {
                    var params = $.param({ pairingid : $stateParams.pairingID });
                    $http.get('https://iwanamaker.com/api/json/pairing_score_data?'+params).then(function(pairingResponse) {
                      scores[$scope.currentHole-1] = index;
                      $scope.golfers = pairingResponse.data.GOLFERS.GOLFER;
                    });
                  });
                  
                  return true;
                 },
               });            
             };
	     
	  $scope.showPuttsSelect = function(putts, roundID) {
            // Show the SCORE SELECT action sheet
            $ionicActionSheet.show({
                 buttons: [{text:'0'},{text:'1'},{text:'2'},{text:'3'},{text:'4'},{text:'5'},{text:'6'},{text:'7'},{text:'8'},{text:'9'},
                           {text:'10'},{text:'11'}],
                 titleText: '<i class="ion-log-in"></i> Enter Putts',
                 cancelText: 'Back',
                 cancel: function() {
                      // add cancel code..
                    },
                 buttonClicked: function(index) {
                  putts[$scope.currentHole-1] = -2;
                  
                  var params = $.param({ roundid : roundID, hole : $scope.currentHole, putts : index });
                  $http.get('https://iwanamaker.com/api/json/update_round_putts?'+params).then(function(response) {
                    putts[$scope.currentHole-1] = index;
                  });
                  
                  return true;
                 },
               });            
             };
          
	  $scope.updateFairway = function(roundID, hit, fairways) {
	        if (hit === true) {
		    hit = 1;
		} else {
		    hit = 0;
		}
		var params = $.param({ roundid : roundID, hole : $scope.currentHole, fairway : hit });
		$http.get('https://iwanamaker.com/api/json/update_round_fairway?'+params).then(function(response) {
		  fairways[$scope.currentHole-1] = hit;
		});
		
		return true;           
          };
          
          $ionicLoading.hide();
      }, function(response) {
            $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
    
    $scope.scorecardZoom = function (eventGolferID) {
      if (eventGolferID) {
          $location.path('/app/events/'+$stateParams.eventID+'/play/personalscorecard/'+eventGolferID);
      }
    }
})

.controller('EditEventCtrl', function($scope, $http, $ionicPopup, $stateParams, $ionicLoading){ 
    $scope.data = {};
    
    var params = $.param({ eventid : $stateParams.eventID });
    
    $ionicLoading.show({
      template: '<ion-spinner icon="lines"></ion-spinner>',
      noBackdrop: true,
duration: 10000
    });
    
    $scope.$on('$ionicView.enter', function(e) {
      $http.get('https://iwanamaker.com/api/json/event_info?'+params).then(function(response) {
          $scope.event = response.data.EVENT;
		  $ionicLoading.hide();
      }, function(response) {
            $ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({
				  title: 'Service Unavailable',
				  template: 'Please make sure you have an active internet connection and try again.'
			});
      });
    });
});

