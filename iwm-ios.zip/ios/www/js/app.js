// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])

.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
  $ionicConfigProvider.tabs.position('bottom');
})

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

    .state('login', {
      url: '/login',
      templateUrl: 'templates/login.html',
      controller: 'LoginCtrl'
  })
    
    .state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html',
    controller: 'AppCtrl'
  })
    
  .state('register', {
      url: '/register',
      templateUrl: 'templates/register.html',
      controller: 'RegisterCtrl'
    })

  .state('app.events', {
      url: '/events',
      views: {
        'menuContent': {
          templateUrl: 'templates/events.html',
          controller: 'EventsCtrl'
        }
      }
    })
  
  .state('app.events.event', {
    url: '/:eventID',
    views: {
      'menuContent@app': {
        templateUrl: 'templates/event.html',
        controller: 'EventCtrl'
      }
    }
  })
  
  .state('app.events.event.eventInfo', {
    url: '/event_info',
    views: {
      'menuContent@app': {
        templateUrl: 'templates/event_info.html',
        controller: 'EventInfoCtrl'
      }
    }
  })
  
  .state('app.events.event.pairingsFor', {
    url: '/pairings_for',
    views: {
      'menuContent@app': {
        templateUrl: 'templates/pairings_for.html',
        controller: 'EventRoundsCtrl'
      }
    }
  })
  
  .state('app.pairings', {
    url: '/events/pairings/:event_roundID',
    views: {
      'menuContent': {
        templateUrl: 'templates/pairings.html',
        controller: 'PairingsCtrl'
      }
    }
  })
  
  .state('app.events.event.play', {
    url: '/play',
    views: {
      'menuContent@app': {
        templateUrl: 'templates/play.html',
        controller: 'PlayCtrl'
      }
    }
  })
  
  .state('app.events.event.play.leaderboard', {
    url: '/leaderboard',
    views: {
      'leaderboard-tab': {
        templateUrl: 'templates/leaderboard.html',
        controller: 'LeaderboardCtrl'
      }
    }
  })
  
  .state('app.events.event.play.team_leaderboard', {
    url: '/team_leaderboard/:teamID',
    views: {
      'leaderboard-tab': {
        templateUrl: 'templates/team_leaderboard.html',
        controller: 'TeamLeaderboardCtrl'
      }
    },
    params: {requestLeaderboard : null},
  })
  
  .state('app.events.event.play.personalscorecard', {
    url: '/personalscorecard/:event_golferID',
    views: {
      'score-tab': {
        templateUrl: 'templates/scorecard.html',
        controller: 'ScorecardCtrl'
      }
    },
  })
  
  .state('app.events.event.play.scorecard', {
    url: '/scorecard/:event_golferID',
    views: {
      'leaderboard-tab': {
        templateUrl: 'templates/scorecard.html',
        controller: 'ScorecardCtrl'
      }
    },
  })
  
  .state('app.events.event.play.scoreForGolfer', {
    url: '/score_for_golfer',
    views: {
      'score-tab': {
        templateUrl: 'templates/score_for_golfer.html',
        controller: 'EventGolfersCtrl'
      }
    }
  })
  
  .state('app.events.event.play.scoreForRound', {
    url: '/score_for_round/:event_golferID',
    views: {
      'score-tab': {
        templateUrl: 'templates/score_for_round.html',
        controller: 'EventGolferRoundsCtrl'
      }
    }
  })
  
  .state('app.events.event.play.score', {
    url: '/score/:pairingID',
    views: {
      'score-tab': {
        templateUrl: 'templates/score.html',
        controller: 'ScoreCtrl'
      }
    }
  })
  
  .state('app.events.event.edit', {
    url: '/edit',
    views: {
      'menuContent@app': {
        templateUrl: 'templates/event_edit.html',
        controller: 'EditEventCtrl'
      }
    }
  })
  
  .state('app.search', {
    url: '/search',
    views: {
      'menuContent': {
        templateUrl: 'templates/search.html'
      }
    }
  })

  .state('app.browse', {
      url: '/browse',
      views: {
        'menuContent': {
          templateUrl: 'templates/browse.html'
        }
      }
    })
    .state('app.playlists', {
      url: '/playlists',
      views: {
        'menuContent': {
          templateUrl: 'templates/playlists.html',
          controller: 'PlaylistsCtrl'
        }
      }
    })

  .state('app.single', {
    url: '/playlists/:playlistId',
    views: {
      'menuContent': {
        templateUrl: 'templates/playlist.html',
        controller: 'PlaylistCtrl'
      }
    }
  });
  
  var uid = window.localStorage.getItem("uid");
  console.log(uid);
  if (uid) {
    $urlRouterProvider.otherwise('/app/events');
  } else {
    $urlRouterProvider.otherwise('/login');
  }
});
